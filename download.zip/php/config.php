<?php
// Define la URL base de tu proyecto.
// Asegúrate de que termine con una barra inclinada (/).
define('BASE_URL', 'http://localhost/ndual/');
?>
